#include "omp_solve_n_queens_v3.h"

#include <omp.h>

unsigned long
omp_solve_n_queens_v3(const int dim) {
    
  // Echiquier.
  int chessboard[dim];

  // Nombre de solutions.
  unsigned long how_many = 0;

  // Nombre de threads disponibles.
  int threads;
  
  /***********************
   * ... à compléter ... *
   ***********************/

  // C'est terminé.
  return how_many;
  
}
